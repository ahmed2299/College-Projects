import numpy as np
#import matplotlib as plt
import pandas as pd
import matplotlib.pyplot as plt
import scipy.stats as stats


m=np.random.randint(7,10,20)


#mean
print(np.mean(m))

#median
print(np.median(m))

#range
n=np.random.randn(9)

print(np.max(n)-np.min(n))

#variance
print(np.var(n))

#standard deviation
print(np.std(n))


#inter quartile range
q1=np.percentile(n,25)

q2=np.percentile(n,50)

q3=np.percentile(n,75)

print(q3-q1)

#box plot




#skewness for iqr

df1=pd.DataFrame(dict(id=range(6),age=np.random.randint(18,31,6)))

print(df1["age"].skew())

#histogram
mu=20
sigma=2
h=sorted(np.random.normal(mu,sigma,100))

plt.hist(h,30,normed=True)
plt.show()

#dot plot
plt.scatter(np.linspace(-1,1,50),np.random.randn(50))
plt.show()

#bar chart
x=[1,2,3]
y=[100,300,50]
plt.bar(x,y)
plt.show()

#box plot

x=np.random.randint(10,20,5)
plt.boxplot(x)
plt.title("Population data")
plt.ylabel("amout of people")
plt.show()

#regression
data=pd.read_csv('headbrain.csv')
print(data.shape)
data.head()
plt.rcParams['figure.figsize']=(20.0,10.0)
data=pd.read_csv('headbrain.csv')
#print(data.shape)
data.head()


x=data['Head size(cm^3)'].values
y=data['Brain Weight(grams)'].values

mean_x=np.mean(x)
mean_y=np.mean(y)
n=len(x)

numerator=0
denomenator=0

for i in range(m):
    numerator+=(x[i]-mean_x)*(y[i]-mean_y)
    denomenator+=(x[i]-mean_x)**2

b1=numerator/denomenator
b0=mean_y-(b1*mean_x)

print(b1,b0)



plt.xlabel('Head size in cm3')
plt.ylabel('Brain weight in grams')
plt.legend()
plt.show()